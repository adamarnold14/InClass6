package com.itcs4155.inclass6;

import org.json.JSONException;
import org.json.JSONObject;

public class Movie {
	
	int id;
	String title, runtime, synopsis;
	
	public Movie(JSONObject movieJSONObject) throws JSONException{
		try{
			id = movieJSONObject.getInt("id");
			title = movieJSONObject.getString("title");
			runtime = movieJSONObject.getString("runtime");
			synopsis = movieJSONObject.getString("synopsis");
			} catch(JSONException e){
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRuntime() {
		return runtime;
	}

	public void setRuntime(String runtime) {
		this.runtime = runtime;
	}
	
	public String getSynopsis() {
		return synopsis;
	}

	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}

	@Override
	public String toString() {
		return "Movie [ID=" + id + ", Title=" + title + ", Runtime=" + runtime
				+ ", Synopsis=" + synopsis + "]";
	}

}