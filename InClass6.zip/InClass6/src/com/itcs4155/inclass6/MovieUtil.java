package com.itcs4155.inclass6;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MovieUtil {	
	static public class MoviesJSONParser{		
		static ArrayList<Movie> parseMovies(String jsonString) throws JSONException{
			ArrayList<Movie> movies = new ArrayList<Movie>();	
			JSONArray moviesJSONArray = new JSONArray(jsonString);
			for(int i=0; i<moviesJSONArray.length(); i++){
				JSONObject movieJSONObject = moviesJSONArray.getJSONObject(i);
				Movie movie = new Movie(movieJSONObject);	
				movies.add(movie);
			}
			return movies;
		}
	}
}