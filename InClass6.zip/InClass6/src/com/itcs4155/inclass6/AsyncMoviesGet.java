package com.itcs4155.inclass6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONException;

import android.os.AsyncTask;
import android.util.Log;

public class AsyncMoviesGet extends AsyncTask<String, Void, ArrayList<Movie>>{
	MainActivity activity;
	
	
	public AsyncMoviesGet(MainActivity activity){
		Log.d("demo", "Gets to Async");
		this.activity = activity;
	}
	
	@Override
	protected ArrayList<Movie> doInBackground(String... params) {
		Log.d("demo", "Gets to doInBackground");
		String urlString = params[0];
		try {
			URL url = new URL(urlString);			
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.connect();			
			int statusCode = con.getResponseCode();
			if (statusCode == HttpURLConnection.HTTP_OK) {				
				BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuilder sb = new StringBuilder();
				String line = reader.readLine();
				Log.d("demo", "line");
				while (line != null) {
					sb.append(line);
					line = reader.readLine();
				}
				ArrayList<Movie> movies = MovieUtil.MoviesJSONParser.parseMovies(sb.toString());
				Log.d("demo", "Finishes Async Test");
				return movies;
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return null;
	}

	@Override
	protected void onPostExecute(ArrayList<Movie> result) {
		if(result != null){
			//activity.setupListView(result);
			Log.d("demo", result.toString());
		} else{
			Log.d("demo", "null result");
		}

	}	
}