/*
 * Adam Arnold and Nick Smythwood
 * In Class Assignment 6
 * 6/11/13
 */

package com.itcs4155.inclass6;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends ListActivity {

	//String moviesJSONUrl = "http://api.rottentomatoes.com/api/public/v1.0/lists/movies/in_theaters.json?page_limit=25&page=1&country=us&apikey=u4f6bc5xxxvdew3uvnvtuw26";

	private static String url = "http://api.rottentomatoes.com/api/public/v1.0/lists/movies/in_theaters.json?page_limit=25&page=1&country=us&apikey=u4f6bc5xxxvdew3uvnvtuw26";
	private static String TAG_MOVIES = "movies";
	private static String TAG_ID = "id";
	private static String TAG_TITLE = "title";
	private static String TAG_RUNTIME = "runtime";
	private static String TAG_SYNOPSIS = "synopsis";
	
	JSONArray jsonmoviearray = null;
	
	// Link:
	// http://api.rottentomatoes.com/api/public/v1.0/lists/movies/in_theaters.json?page_limit=25&page=1&country=us&apikey=
	// API KEY: u4f6bc5xxxvdew3uvnvtuw26
	
	//response=new JSONObject(String);
	//JSONArray moviesJS = response.getJSONArray("movies");
	//JSONObject m = moviesJS.getJSONObject(O);
	//ArrayList<Movie> movies;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ArrayList<HashMap<String, String>> movieList = new ArrayList<HashMap<String, String>>();

		// Creating JSON Parser instance
		JSONParser jParser = new JSONParser();
		 
		// Get JSON string from URL
		JSONObject json = jParser.getJSONFromUrl(url);
		 
		try {
		    // Getting Array of Contacts
		    jsonmoviearray = json.getJSONArray(TAG_MOVIES);
		     
		    // looping through All Contacts
		    for(int i = 0; i < jsonmoviearray.length(); i++){
		        JSONObject c = jsonmoviearray.getJSONObject(i);
		         
		        // Storing each json item in variable
		        String id = c.getString(TAG_ID);
		        String title = c.getString(TAG_TITLE);
		        String runtime = c.getString(TAG_RUNTIME);
		        String synopsis = c.getString(TAG_SYNOPSIS);
		    }
		} catch (JSONException e) {
		    e.printStackTrace();
		}
		
        /**
         * Updating parsed JSON data into ListView
         * */
        ListAdapter adapter = new SimpleAdapter(this, movieList,
                R.layout.mylist,
                new String[] { TAG_ID, TAG_TITLE, TAG_RUNTIME, TAG_SYNOPSIS }, new int[] {
                        R.id.id, R.id.title, R.id.runtime, R.id.synopsis 
                        });
        setListAdapter(adapter);
 
        
 
        // selecting single ListView item
        ListView lv = getListView();
 
        // Launching new screen on Selecting Single ListItem
        lv.setOnItemClickListener(new OnItemClickListener() {
 
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                    int position, long id) {
                // getting values from selected ListItem
                String id = ((TextView) view.findViewById(R.id.id)).getText().toString();
                String title = ((TextView) view.findViewById(R.id.title)).getText().toString();
                String runtime = ((TextView) view.findViewById(R.id.runtime)).getText().toString();
                String synopsis = ((TextView) view.findViewById(R.id.synopsis)).getText().toString();
                 
                // Starting new intent
                Intent in = new Intent(getApplicationContext(), SingleMenuItemActivity.class);
                in.putExtra(TAG_ID, id);
                in.putExtra(TAG_TITLE, title);
                in.putExtra(TAG_RUNTIME, runtime);
                in.putExtra(TAG_SYNOPSIS, synopsis);
                startActivity(in);
            }
        });
    }
		//Log.d("demo", "Before Async");
		
		//new AsyncMoviesGet(this).execute(moviesJSONUrl);
/*
	public void setupListView(ArrayList<Movie> result){
		Log.d("demo", "Started setupListView");
		ListView myListView = (ListView) findViewById(R.id.mylist);
		this.movies = result;

		ArrayAdapter<Movie> adapter = new ArrayAdapter<Movie>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1, movies);
		myListView.setAdapter(adapter);
		adapter.setNotifyOnChange(true);

		myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				Log.d("demo", movies.get(position).toString());
			}
		});
		Log.d("demo", "Finished setupListView");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public static class MovieAdapter extends ArrayAdapter<Movie> {
		Context context;
		Movie[] objects;

		public MovieAdapter(Context context, Movie[] objects) {
			super(context, R.layout.detailedlayout, objects);
			this.context = context;
			this.objects = objects;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			Log.d("demo", "Started getView");
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View itemRowView = inflater.inflate(R.layout.detailedlayout, parent,
					false);
			TextView movieName = (TextView) itemRowView
					.findViewById(R.id.title);
			movieName.setText(objects[position].title);
			Log.d("demo", "Finished getView");
			return itemRowView;
		}
	}
	*/
	}
}
