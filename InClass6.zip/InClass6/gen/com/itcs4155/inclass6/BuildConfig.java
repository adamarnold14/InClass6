/** Automatically generated file. DO NOT MODIFY */
package com.itcs4155.inclass6;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}